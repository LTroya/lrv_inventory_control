<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

/**
 * Auth Routes ...
 */
Route::post('auth/login', 'AuthController@getLogin');
Route::post('auth/logout', 'AuthController@Logout');

/**
 * Product Routes...
 */
Route::get('/products/{limit?}', 'ProductController@index');
Route::get('/products/search/{code}/{limit?}', 'ProductController@searchProducts');
Route::post('/products/import', 'ProductController@importSheets');
Route::post('/product', 'ProductController@store');
Route::delete('/product/{product}', 'ProductController@destroy');

/**
 * Manual Migrations execution commands...
 */
Route::get('migrate', function () {

    echo '<br>init with Migrate tables ...';
    Artisan::call('migrate', ['--quiet' => true, '--force' => true]);
    echo '<br>done with Migrate tables';
    echo '<br>init with seed tables ...';
    Artisan::call('db:seed', ['--quiet' => true, '--force' => true]);
    echo '<br>done with seed tables';
});


