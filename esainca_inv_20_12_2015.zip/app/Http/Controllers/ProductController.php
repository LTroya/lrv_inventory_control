<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Http\Requests\CreateProductRequest;
use Maatwebsite\Excel\Facades\Excel;
use Validator;
use File;
use Input;

class ProductController extends Controller
{
    /**
     * @param Request $request
     * @param int $limit
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request, $limit = 20)
    {
        $products = Product::paginate($limit);
        return response()->json($products);
    }

    /**
     * @param Requests\CreateProductRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(CreateProductRequest $request)
    {
        $product = Product::create($request->all());
        return response()->json(["status" => "OK", "product" => $product]);
    }

    /**
     * @param Request $request
     * @param Product $product
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function destroy(Request $request, Product $product)
    {
        $product->delete();
        return response()->json(["status" => "OK", "messages"=>["message" => "Producto eliminado"]]);
    }

    /**
     * @param Request $request
     * @param $code
     * @param int $limit
     * @return mixed
     */
    public function searchProducts(Request $request, $code, $limit = 20)
    {
        return Product::where('code', 'LIKE', '%'. $code. '%')->paginate($limit);
    }

    /**
     * @param Request $request
     * @return array|\Illuminate\Http\JsonResponse|null|\Symfony\Component\HttpFoundation\File\UploadedFile
     */
    public function importSheets(Request $request)
    {
        $folder = '../uploads/';

        $this->createUploadFolder($folder);

        // Validar si se recibe un archivo
        if (empty($_FILES['file'])) {
            return response()->json(['status'=>'error', "messages"=>['message'=> 'No se recibio ningún archivo']]);
        }

        // Informacion del archivo
        $file = $_FILES['file'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $fileName = pathinfo($file['name'], PATHINFO_FILENAME);

        // Validar que la extension sea xlsx
        if ( $ext !== 'xlsx') {
                return response()->json(['status'=>'error', "messages"=>['message'=> 'Solo se permite importar archivos .xlsx']]);
        }

        $today = date('Y-m-d_H-i-s');
        $fileName = "{$fileName}_{$today}.{$ext}";
        // Mover el archivo a la carpeta upload
        move_uploaded_file($file['tmp_name'], $folder . $fileName);
        // Obtener las filas del archivo
        $sheets = Excel::load($folder . $fileName, function ($reader) {})->get();
        // Borrar el archivo luego de haberlo usado
        unlink($folder . $fileName);
        // Retornar la cantidad de registros nuevos de la base de datos
        return response()->json($this->saveSheet($sheets));

    }

    /**
     * @param $reader
     * @return array
     */
    private function saveSheet($reader)
    {
        $rows = $reader->all();
        $newProducts = 0;
        foreach ($rows as $row) {
            $product = Product::where('code', 'LIKE', $row->orden_n)->first();
            if (!$product) {
                $newProducts++;
                $product = new Product(['code' => $row->orden_n, 'style' => $row->nombre, 'measure' => $row->medida]);
                $product->save();
            }
        }
        return ['newRecords' => $newProducts];
    }

    private function createUploadFolder($folder)
    {
        if(!is_dir($folder)){
            mkdir("../uploads",0777);
        }
    }
}
