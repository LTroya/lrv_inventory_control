<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Http\Requests\DoLoginRequest;
use Auth;

class AuthController extends Controller
{
    public function getLogin(DoLoginRequest $request)
    {
        $data = ['email' => $request->input('email'), 'password' => $request->input('password')];
        if (Auth::attempt($data)) {
            return response()->json(["status" => "ok", "messages" => ["message" => "Logeado"]]);
        }
        return response()->json(["status" => "error", "messages" => ["message" => "El usuario y/o el password no son correctos."]]);
    }

    public function Logout()
    {
        Auth::logout();
        return response()->json(["status" => "ok", "messages" => ["message" => "Deslogueado"]]);
    }
}
